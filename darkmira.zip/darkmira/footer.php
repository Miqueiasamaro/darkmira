	
	<?php wp_footer(); ?>
	<link href="<?php bloginfo('template_url'); ?>/assets/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
	<script src="<?php bloginfo('template_url'); ?>/assets/js/img-upload.js"></script>
	<link href="<?php bloginfo('template_url'); ?>/assets/css/img-upload.css" rel="stylesheet">
	</body>
</html>
